$(document).ready(function(){
  AOS.init({
    duration: 800 // values from 0 to 3000, with step 50ms
  });

  $(".nascimento").mask("99/99/9999");
  $(".whatsapp").mask("(99) 99999-9999");
  $(".cpf").mask("999.999.999-99");

  $('#form1').validate({
    rules: {
      nome: { required: true, minlength: 2 },
      email: { required: true, email: true },
      whatsapp: { required: true, minlength: 10 }
    },
    messages: {
      nome: { required: 'Preencha o campo nome', minlength: 'No mínimo 2 letras' },
      email: { required: 'Informe o seu email', email: 'Ops, informe um email válido' },
      whatsapp: { required: 'Nos diga seu telefone', minlength: 'No mínimo 10 dígitos' }
    }
  });
  $('#form2').validate({
    rules: {
      nome: { required: true, minlength: 2 },
      email: { required: true, email: true },
      whatsapp: { required: true, minlength: 10 }
    },
    messages: {
      nome: { required: 'Preencha o campo nome', minlength: 'No mínimo 2 letras' },
      email: { required: 'Informe o seu email', email: 'Ops, informe um email válido' },
      whatsapp: { required: 'Nos diga seu telefone', minlength: 'No mínimo 10 dígitos' }
    }
  });
});